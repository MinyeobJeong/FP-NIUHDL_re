clear all
clc

A=160*1000*1000;
lambda=0.01;
IUH=load('../IUH_Module/File_1_ydl.txt');
CN=load('../LSTM_Module/File_4.txt');
dtimeiuh=60;
Ntimeiuh=width(IUH);
Nio=200;

event=0;
while event<7

event=event+1;

data=load(['Input_data_file_3_ydl_event' num2str(event) '.txt']);


dtime=60;
dtime_data=60*60;
endtime=height(data)*dtime_data;

for i=1:endtime/dtime+1
    t(i)=dtime*(i-1);
    for j=1:Nio
        t_all(j,i)=t(i);
    end
end

data=[data; data(end,:)];
tdata=data(:,1)*dtime_data;
tdata(end)=tdata(end)+dtime_data;
rain=interp1(tdata',data(:,2)',t);
Qobs=interp1(tdata',data(:,3)',t);
for i=1:height(Qobs)
    baseflow(i)=Qobs(1);
end

for j=1:Nio
    for i=1:Ntimeiuh*dtimeiuh/dtime        
        u(j,i)=IUH(j,1+dtime/dtimeiuh*(i-1));
    end
    for i=Ntimeiuh*dtimeiuh/dtime+1:endtime/dtime+1
        u(j,i)=0;
    end
end

S=25400/CN(event)-254; %NRCS-S(mm)

for i=1:endtime/dtime+1
    accrain(i)=0; %accumulated rainfall depth (mm)
    for j=1:i
        accrain(i)=accrain(i)+rain(j)*dtime/3600;      
    end
end

for i=1:endtime/dtime+1
    if accrain(i)>lambda*S
        acceffrain(i)=((accrain(i)-lambda*S)^2)/...
            (accrain(i)+(1-lambda)*S);
        %accumulated effective rainfall depth (mm)
    else
        acceffrain(i)=0;
    end
end

for i=2:endtime/dtime+1
    effrain(i)=(acceffrain(i)-acceffrain(i-1))/...
        dtime*3600; %effective rainfall intensity (mm/hr)
end



%DRH using convolution integral
number=1;
while number<=endtime/dtime+1
    qq=0;
    for i=1:number
        q(i)=u(max(1,round(effrain(i))),max(1,number-(i-1)))... %u(t-tau)
               *A...                                            %A
               *effrain(i)/1000/3600 ...                        %i(t)
               *dtime ;                                         %dtau
    end
    for i=1:number                                              %0~t
    qq=qq+q(i);                                                 %integral
    end
    Q(number)=qq;
    number=number+1;
end
Q=Q+baseflow;


%nse
for i=1:length(t)
    erQ(i)=(Qobs(i)-Q(i))^2;
end
serQ=0;
for i=1:length(t)
    serQ=serQ+erQ(i);
end
sumQobs=0;
for i=1:length(t)
    sumQobs=sumQobs+Qobs(i);
end
avgQobs=sumQobs/length(t);
for i=1:length(t)
    devQobs(i)=(Qobs(i)-avgQobs)^2;
end
sdevQobs=0;
for i=1:length(t)
    sdevQobs=sdevQobs+devQobs(i);
end
NSE=1-(serQ/sdevQobs);
%r^2
sumQ=0;
for i=1:length(t)
    sumQ=sumQ+Q(i);
end
avgQ=sumQ/length(t);
for i=1:length(t)
    devQ(i)=(Q(i)-avgQ)^2;
end
sdevQ=0;
for i=1:length(t)
    sdevQ=sdevQ+devQ(i);
end
for i=1:length(t)
    devQos(i)=(Qobs(i)-avgQobs)*(Q(i)-avgQ);
end
sdevQos=0;
for i=1:length(t)
    sdevQos=sdevQos+devQos(i);
end
Rsquared=(sdevQos^2)/(sdevQobs*sdevQ);
%       very good     good    satisfactory
%NSE       0.8        0.7         0.5     
%R^2       0.85       0.7         0.5
if NSE>=0.8
    judgeNSE='Very Good';
elseif NSE>=0.7
    judgeNSE='Good';
elseif NSE>=0.5
    judgeNSE='Satisfactory';
else
    judgeNSE='Unsatisfactory';
end
if Rsquared>=0.85
    judgeRsquared='Very Good';
elseif Rsquared>=0.7
    judgeRsquared='Good';
elseif Rsquared>=0.5
    judgeRsquared='Satisfactory';
else
    judgeRsquared='Unsatisfactory';
end

gcf=figure(53)
subplot(2,4,event)
stairs(t/3600,rain,'-k','Linewidth',1.3)
hold on
stairs(t/3600,effrain,'-b','Linewidth',1.3)
xlim([0 0.7*max(t/3600)])
ylim([0 max(max(rain),max(effrain))*1.3])
xlabel('time (hr)')
ylabel('Rainfall (mm/hr)')
set(gca,'FontSize',18)
set(gca,'fontname','times')
p=sprintf('<Event %d>',event);
title(p)
print=sprintf('CN= %.1f',CN(event));
for i=1:length(t)
if rain(i)==max(rain)
    tp=t(i);
end
end
if tp<0.5*endtime
text(0.42*max(t/3600),1.15*max(max(rain),max(effrain)),print,'FontSize',17,'fontname','times')
else
text(0.05*max(t/3600),1.15*max(max(rain),max(effrain)),print,'FontSize',17,'fontname','times')
end

if event==7
subplot(2,4,8)
stairs(t/3600,rain,'-k','Linewidth',1.3)
hold on
stairs(t/3600,effrain,'-b','Linewidth',1.3)
axis([-11,-10,-11,-10])
legend('Rainfall','Effective Rainfall')
legend boxoff
axis off
set(gca,'FontSize',20)
set(gca,'fontname','times')
legend('Location','southeast')

sgtitle('[Rainfall hyetographs and Effetive rainfall hyetographs (Yuldongli Gauge)]','FontSize',24,'fontname','times')
end

set(gcf,'units','normalized','outerposition',[0.1 0.1 0.88 0.75]);


gcf=figure(54)
subplot(2,4,event)
plot(t/3600,Qobs,'-k','Linewidth',1.3)
hold on
plot(t/3600,Q,'-r','Linewidth',1.3)
xlim([0 max(t/3600)])
ylim([0 max(max(Qobs),max(Q))*1.4])
xlabel('time (hr)')
ylabel('Discharge (m^3/s)')
set(gca,'FontSize',18)
set(gca,'fontname','times')
p=sprintf('<Event %d>',event);
title(p)
print=sprintf('NSE= %.2f\n(%s)\nR^2= %.2f\n(%s)',NSE,judgeNSE,Rsquared,judgeRsquared);
for i=1:length(t)
if Q(i)==max(Q)
    tp=t(i);
end
end
if tp<0.5*endtime
text(0.53*max(t/3600),1.07*max(max(Qobs),max(Q)),print,'FontSize',15,'fontname','times')
else
text(0.05*max(t/3600),1.07*max(max(Qobs),max(Q)),print,'FontSize',15,'fontname','times')
end

if event==7
subplot(2,4,8)
plot(t/3600,Qobs,'-k','Linewidth',1.3)
hold on
plot(t/3600,Q,'-r','Linewidth',1.3)
axis([-11,-10,-11,-10])
legend('Observed','Simulated')
legend boxoff
axis off
set(gca,'FontSize',20)
set(gca,'fontname','times')
legend('Location','southeast')

sgtitle('[Flood hydrographs (Yuldongli Gauge)]','FontSize',24,'fontname','times')
end

set(gcf,'units','normalized','outerposition',[0.1 0.1 0.88 0.75]);

clearvars -except event A lambda IUH CN dtimeiuh Ntimeiuh Nio
end