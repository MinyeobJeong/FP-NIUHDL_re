clear all
clc

% time
endtime=2800*60; % end time (s)
dtime=60; % time interval (s)
for i=2:endtime/dtime+1
    t(i)=dtime*(i-1); % time (s)
end

% rainfall excess intensity, i_o=1~200 mm/hr, 1mm/hr interval
Nio=200;
for j=1:Nio
    io(j)=j;
end

% Watershed area (m^2)
A=209*1000*1000;

% Input data -> option 1: IUHs (s^-1), option 2: S-hydrographs (m^3/s)
option=2;
if option==1
    Data=load('Input_data_file_1_hsd_option1.txt');
elseif option==2
    Data=load('Input_data_file_1_hsd_option2.txt');
end

% io value corresponding to input data (mm/hr)
iready=[10; 20; 50; 100; 200];

if option==1
    for j=1:Nio
        for i=2:endtime/dtime+1
            uk(j,i)=0;
            uk(iready(1),i)=max(0,Data(1,i));
            uk(iready(2),i)=max(0,Data(2,i));  % Known IUHs
            uk(iready(3),i)=max(0,Data(3,i));
            uk(iready(4),i)=max(0,Data(4,i));
            uk(iready(5),i)=max(0,Data(5,i));
            Shyd(j,i)=A*dtime*sum(uk(j,1:i))*io(j)/1000/3600; % Known S-hydrographs
        end
    end
elseif option==2
    for j=1:Nio
        for i=2:endtime/dtime+1
            Shyd(j,i)=0;
            Shyd(iready(1),i)=max(0,Data(1,i));
            Shyd(iready(2),i)=max(0,Data(2,i));  % Known S-hydrographs
            Shyd(iready(3),i)=max(0,Data(3,i));
            Shyd(iready(4),i)=max(0,Data(4,i));
            Shyd(iready(5),i)=max(0,Data(5,i));
        end
        for i=2:endtime/dtime
            uk(j,i)=max(0,((Shyd(j,i+1)-Shyd(j,i-1))/(t(i+1)-t(i-1)))...
                /(io(j)/1000/3600)/A);
        end                                       % Known IUHs
        for i=endtime/dtime+1:endtime/dtime+1
            uk(j,i)=0;                            
        end
    end
end

% IUH interpolation
for k=1:size(iready)
    ukp(k)=max(uk(iready(k),:)); % Peak of uk
    for i=1:endtime/dtime+1
        if uk(iready(k),i)==ukp(k)
            tkp(k)=t(i); % Peak time of uk
        end
    end
end
ukp=ukp';
tkp=tkp';
fup=polyfit(log10(iready),log10(ukp),1); % Power regression
ftp=polyfit(log10(iready),log10(tkp),1);
alpha=fup(1); % exponents
beta=ftp(1);
zeta=10^fup(2); % coefficients
epsilon=10^ftp(2);
for j=1:Nio 
    i_ref=iready(3); % reference io
    ukp_ref=ukp(3); % reference ukp
    tkp_ref=tkp(3); % reference tkp
    for i=1:endtime/dtime+1
    Shyd_ref(i)=Shyd(i_ref,i); % reference IUH
    uk_ref(i)=uk(i_ref,i); % reference S-hydrograph
    end
    % Interpolation
    for i=1:endtime/dtime+1
        unew(j,i)=uk_ref(i)*zeta*(io(j)^alpha)/ukp_ref;
    end
    for i=1:tkp_ref/dtime
        tnew(j,i)=(epsilon*(io(j)^beta)/tkp_ref)*t(i);
    end
    for i=tkp_ref/dtime+1:endtime/dtime+1
        tnew(j,i)=(A*i_ref-(zeta*epsilon*(io(j)^(alpha+beta))/ukp_ref/tkp_ref)...
            *Shyd_ref(tkp_ref/dtime+1))/((zeta*(io(j)^alpha)/ukp_ref)*...
            (A*i_ref-Shyd_ref(tkp_ref/dtime+1)))*(t(i)-tkp_ref)+epsilon*(io(j)^beta);
    end
    for i=endtime/dtime+1:endtime/dtime+1
        tnew(j,i)=max(tnew(end),t(end));
    end    
end
number=1;
while number<=Nio   % tnew -> t
    for i=1:endtime/dtime+1
    tnewp(i)=tnew(number,i);
    unewp(i)=unew(number,i);
    end
    usubp=interp1(tnewp,unewp,t);
    for i=1:endtime/dtime+1
    un(number,i)=usubp(i);      % New IUH
    end
    number=number+1;
end

%_______________________________________________________________________________________________________________________________________________________________

gcf=figure (11) % Figure: Known S-hydrographs
subplot(1,2,1)
plot(t/60/60,Shyd(200,:)/io(200)*1000*3600/A,'LineWidth',2.2,'color','r','linestyle','-')
hold on
plot(t/60/60,Shyd(100,:)/io(100)*1000*3600/A,'LineWidth',2.2,'color','[1 0.8 0.1]','linestyle','-')
hold on
plot(t/60/60,Shyd(50,:)/io(50)*1000*3600/A,'LineWidth',2.2,'color','[0 0.5 0]','linestyle','-')
hold on
plot(t/60/60,Shyd(20,:)/io(20)*1000*3600/A,'LineWidth',2.2,'color','b','linestyle','-')
hold on
plot(t/60/60,Shyd(10,:)/io(10)*1000*3600/A,'LineWidth',2.2,'color','[0.7 0.0 0.7]','linestyle','-')
xlabel('time (hr\rm)')
set(gca,'FontSize',20)
set(gca,'fontname','times')
ylabel('$\frac{S}{i_oA}$','Interpreter','latex','FontSize',30)
xlim([0 endtime/60/60])
ylim([0 1.2])
title('[S-hydrographs]')
hold off

subplot(1,2,2) % Figure: Known IUHs
plot(t/60/60,uk(200,:)*60*60,'-', 'HandleVisibility','on','LineWidth',2.2,'color','r')
hold on
plot(t/60/60,uk(100,:)*60*60,'-', 'HandleVisibility','on','LineWidth',2.2,'color','[1 0.8 0.1]')
hold on
plot(t/60/60,uk(50,:)*60*60,'-', 'HandleVisibility','on','LineWidth',2.2,'color','b')
hold on
plot(t/60/60,uk(20,:)*60*60,'-', 'HandleVisibility','on','LineWidth',2.2,'color','[0 0.5 0]')
hold on
plot(t/60/60,uk(10,:)*60*60,'-', 'HandleVisibility','on','LineWidth',2.2,'color','[0.7 0.0 0.7]')
hold on
xlabel('time (hr\rm)')
legend('\iti_o\rm=200 mm/hr','\iti_o\rm=100 mm/hr','\iti_o\rm=50 mm/hr','\iti_o\rm=20 mm/hr','\iti_o\rm=10 mm/hr')
legend('location','northeast')
set(gca,'FontSize',20)
set(gca,'fontname','times')
ylabel('IUH (hr^-^1)')
yticks([0 0.2 0.4 0.6 0.8])
xlim([0 max(tkp)*2.5/60/60])
ylim([0 max(ukp)*1.1*60*60])
legend boxoff
title('[Original IUHs]')
hold off
set(gcf,'units','normalized','outerposition',[0.15 0.2 0.5 0.45]);

gcf=figure(12) % Figure: Power regression results
subplot(1,2,1)
loglog(iready,ukp*60*60,'s','LineWidth',2,'color','k')
xlabel('\iti_o \rm(mm/hr\rm)')
ylabel('Peak flow \rm(hr^-^1\rm)')
fhatup=10.^[polyval(fup,[min(log10(iready)) max(log10(iready))])];  % evaluate at end points
hold on
loglog([min(iready) max(iready)],fhatup*3600,'LineWidth',1.3,'color','k','linestyle','-') % add fitted line
hold on
p1=plot([1 1], [1 1],'color','none')
hold on
p2=plot([1 1], [1 1],'color','none')
xlim([0.8*min(iready) 1.2*max(iready)])
ylim([0.8*min(ukp*60*60) 1.2*max(ukp*60*60)])
set(gca,'FontSize',20)
set(gca,'fontname','times')
legend('Location','southeast')
print1=sprintf('= %.2f',alpha);
print2=sprintf('= %.6f',zeta);
legend([p1 p2],['\alpha' print1], ['\zeta' print2 '    '],'FontSize',20)
legend boxoff
title('[Peak flow]')
xticks([10 20 50 100 200])
hold off

subplot(1,2,2)
loglog(iready,tkp/60/60,'s','LineWidth',2,'color','k')
xlabel('\iti_o \rm(mm/hr\rm)')
ylabel('Peak time \rm(hr)')
fhattp=10.^[polyval(ftp,[min(log10(iready)) max(log10(iready))])];  % evaluate at end points
hold on
loglog([min(iready) max(iready)],fhattp/3600,'LineWidth',1.3,'color','k','linestyle','-') % add fitted line
hold on
p1=plot([1 1], [1 1],'color','none')
hold on
p2=plot([1 1], [1 1],'color','none')
xlim([0.8*min(iready) 1.2*max(iready)])
ylim([0.8*min(tkp/60/60) 1.2*max(tkp/60/60)])
set(gca,'FontSize',20)
set(gca,'fontname','times')
legend('Location','southwest')
print1=sprintf('= %.2f',beta);
print2=sprintf('= %.1f',epsilon);
legend([p1 p2],['\beta' print1], ['\epsilon' print2],'FontSize',20)
legend boxoff
title('[Peak time]')
xticks([10 20 50 100 200])
hold off
set(gcf,'units','normalized','outerposition',[0.15 0.2 0.45 0.45]);

gcf=figure (13) % Figure: Interpolated IUHs (every 5 mm/hr)
for j=1:floor(Nio/5)
    p1=plot(t/60/60,un((j-1)*5+5,:)*60*60,'LineWidth',0.01,'color','[0.5 0.5 0.5]','linestyle','-', 'HandleVisibility','off')
    hold on
end
p2=plot(t/60/60,un(200,:)*60*60,'LineWidth',2.2,'color','r','linestyle','-', 'HandleVisibility','on')
hold on
p3=plot(t/60/60,un(100,:)*60*60,'LineWidth',2.2,'color','[1 0.8 0.1]','linestyle','-', 'HandleVisibility','on')
hold on
p4=plot(t/60/60,un(50,:)*60*60,'LineWidth',2.2,'color','b','linestyle','-', 'HandleVisibility','on')
hold on
p5=plot(t/60/60,un(20,:)*60*60,'LineWidth',2.2,'color','[0 0.5 0]','linestyle','-', 'HandleVisibility','on')
hold on
p6=plot(t/60/60,un(10,:)*60*60,'LineWidth',2.2,'color','[0.7 0.0 0.7]','linestyle','-', 'HandleVisibility','on')
hold on
xlabel('time (hr\rm)')
legend([p1 p2 p3 p4 p5 p6],...
    '\iti_o= \rm5-200 mm/hr','\iti_o\rm=200 mm/hr','\iti_o\rm=100 mm/hr','\iti_o\rm=50 mm/hr','\iti_o\rm=20 mm/hr','\iti_o\rm=10 mm/hr')
legend('location','northeast')
set(gca,'FontSize',20)
set(gca,'fontname','times')
ylabel('IUH (hr^-^1)')
yticks([0 0.2 0.4 0.6 0.8])
xlim([0 max(tkp)*2.5/60/60])
ylim([0 max(ukp)*1.1*60*60])
title('[Interpolated IUHs]')
legend boxoff
hold off
set(gcf,'units','normalized','outerposition',[0.15 0.2 0.37 0.45]);

fopen('File_1_hsd.txt','w');  % Write interpolated IUHs to a file
dlmwrite('File_1_hsd.txt',un)
