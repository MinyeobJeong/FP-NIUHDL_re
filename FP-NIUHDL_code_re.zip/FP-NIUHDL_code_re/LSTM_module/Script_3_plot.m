clear all
clc

vc1=load('File_3.txt');

name_vc=["number of variables";...
"maxEpochs";...
"InitialLearnRate";...
"miniBatchSize";...
"numlayer";...
"numHiddenUnits";...
"DropoutRate";...
"ValidationFrequency";...
"NSE";...
"NRMSE";...
"CR";...
"NMAE";...
"Average"];

Cross=table(name_vc,vc1);

for i=1:width(vc1)
vc1(10,i)=vc1(10,i);
vc1(12,i)=vc1(12,i);
end

for i=1:width(vc1)
    if vc1(end,i)==max(vc1(end,:))
        numfac=vc1(1,i)
    end
end

micpcc_all=load('File_2_0.txt');

variable_name(1)="P";
variable_name(2)="D";
variable_name(3)='ARI';
variable_name(4)='MRI';
variable_name(5)='Evap_tavg';
variable_name(6)='SoilMoi0_10cm_inst';
variable_name(7)='SoilMoi10_40cm_inst';
variable_name(8)='SoilMoi40_100cm_inst';
variable_name(9)='SoilMoi100_200cm_inst';
variable_name(10)='PotEvap_tavg';
variable_name(11)='ECanop_tavg';
variable_name(12)='Tveg_tavg';
variable_name(13)='ESoil_tavg';
variable_name(14)='RootMoist_inst';

ZZ1 = [micpcc_all(1,:); (micpcc_all(2,:)); (micpcc_all(1,:)+abs(micpcc_all(2,:)))/2];
ZZ1(:,numfac+1:end)=[];
variable_name(numfac+1:end)=[];
Z1 = table(variable_name', ZZ1(1,:)', ZZ1(2,:)', ZZ1(3,:)',...
    'VariableNames',["Factor", "MIC", "abs(PCC)", "AVG"]);
Z1 = sortrows(Z1,'AVG','descend');
X1 = categorical(table2array(Z1(:,1)));
X1 = reordercats(X1,table2array(Z1(:,1)));
Y1 = table2array(Z1(:,2:4));
Y1(:,3)=[];

gcf=figure(31)
plot(vc1(1,:),vc1(9,:),'LineWidth',1.5,'color','[0 0.4470 0.7410]','linestyle','-')
hold on
plot(vc1(1,:),1-vc1(10,:),'LineWidth',1.5,'color','[0.8500 0.3250 0.0980]','linestyle','-')
hold on
plot(vc1(1,:),vc1(11,:),'LineWidth',1.5,'color','[0.9 0.6 0.1]','linestyle','-')
hold on
plot(vc1(1,:),1-vc1(12,:),'LineWidth',1.5,'color','[0.4660 0.6740 0.1880]','linestyle','-')
hold on
plot([numfac numfac],[0 1],'LineWidth',2,'color','k','linestyle',':')
xlabel('Number of variables')
ylabel('Evaluation Metric')
xlim([min(vc1(1,:))-0.5 max(vc1(1,:))+0.5])
ylim([0 1])
set(gca,'FontSize',20)
set(gca,'fontname','times')
title('[LSTM optimization result]')
legend('\itNSE','\it1-NRMSE','\itCR','\it1-NMAE','location','southeastoutside')
legend boxoff
set(gcf,'units','normalized','outerposition',[0.15 0.2 0.32 0.45]);

gcf=figure(32)
b=bar(X1,abs([Y1(:,2) Y1(:,1)]),'stacked','BarWidth',1)
b(1).FaceColor = [1 0.45 0.2];
b(2).FaceColor = [1 0.9 0.4];
hold on
plot([0.5 numfac+0.5],[1 1],'LineWidth',0.6,'color','[0.6 0.6 0.6]')
hold on
plot([0.5 numfac+0.5],[0.5 0.5],'LineWidth',0.6,'color','[0.6 0.6 0.6]')
hold on
plot([0.5 numfac+0.5],[1.5 1.5],'LineWidth',0.6,'color','[0.6 0.6 0.6]')
hold on
for i=1:height(Y1)
    plot([0.5+(i-1) 0.5+(i-1)], [0 2],'LineWidth',0.6,'color','[0.6 0.6 0.6]','linestyle','-')
    hold on
end
itt=0;
while itt<100
    itt=itt+1;
uistack(b)
end
for i=1:height(Y1)
    if Y1(i,2)<0
       b2=bar(X1(i),abs(Y1(i,2)),'BarWidth',1);
       b2.FaceColor = [0.2 0.45 1];
    end
end
box on
title('[Selected variables]')
set(gca, 'TickLabelInterpreter', 'none','Fontsize',20,'Fontname','times')
% xtickangle(90)
% ytickangle(90)
yticks([0 0.5 1 1.5 2])
ylim([0 2])
XL = get(gca, 'XLim')
xlim(XL)
ylabel('\itMIC+\rm|\itPCC\rm|\rm')
camroll(-90)
legend([b(2) b(1) b2],'\itMIC','\itPCC \rm(+)','\itPCC \rm(-)')
legend('location','southeast')
set(gca,'xaxisLocation','top')
set(gca,'yaxisLocation','right')

set(gcf,'units','normalized','outerposition',[0.15+0.33 0.2 0.32 0.45]);