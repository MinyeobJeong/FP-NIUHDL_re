clear all;clc;

Redata=load('File_2.txt');
opt_result=load('File_3.txt');
Oridata=load('Input_data_file_2.txt');

for j=1:width(opt_result)
    if opt_result(13,j)==max(opt_result(13,:));
        numfactor = opt_result(1,j);
        maxEpochs = opt_result(2,j);
        InitialLearnRate = opt_result(3,j);
        miniBatchSize = opt_result(4,j);
        numlayer = opt_result(5,j);
        numHiddenUnits = opt_result(6,j);
        DropoutRate = opt_result(7,j);
        ValidationFrequency = opt_result(8,j);
    end
end

testdata = [Redata(ceil(0.8*end)+1:end,end)...
    Redata(ceil(0.8*end)+1:end,1:numfactor)];
Data = [Redata(1:ceil(0.8*end),end)...
    Redata(1:ceil(0.8*end),1:numfactor)];
P = [Oridata(ceil(0.8*end)+1:end,1)];

Results_test = LSTM_testing(Data,...
     numlayer,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
     InitialLearnRate,ValidationFrequency,testdata);

Peo= Results_test.Ytest_raw;
Pes= Results_test.Y_test;
 
gcf=figure(41)
plot(Peo ,Pes,'-o','LineWidth',1.5,'color','k','linestyle','none')
hold on
xlabel('observed \itP_e')
ylabel('predicted \itP_e')
plot([0 1.1*max([Peo ;Pes])],[0 1.1*max([Peo ;Pes])],'LineWidth',1.5,'color','k','linestyle','-')
xlim([0 1.1*max([Peo ;Pes])])
ylim([0 1.1*max([Peo ;Pes])])
title('[LSTM test result]')
set(gca,'FontSize',20)
set(gca,'fontname','times')
set(gcf,'units','normalized','outerposition',[0.15 0.2 0.235 0.45]);
print=sprintf('NSE= %.2f\nNRMSE= %.2f\nCR= %.2f\nNMAE= %.2f\n',...
    round(Results_test.NS_test(1),2),...
    round(Results_test.NRMSE_test(1),2),...
    round(Results_test.CR_test(1),2),...
    round(Results_test.NMAE_test(1),2));
text(0.6*max([Peo ;Pes]),0.175*max([Peo ;Pes]),print,'FontSize',16,'fontname','times')

lambda=0.01;
for i=1:height(P)
Pes(i)=min(P(i),Pes(i));
CN(i)=25400/(P(i)/lambda+((1-lambda)*Pes(i)-...
    ((1-lambda)^2*Pes(i)^2+4*lambda*P(i)*Pes(i))^0.5)/2/lambda^2+254);
end
dlmwrite('File_4.txt',CN');

%% Function test
function Results_test = LSTM_testing(Data,numlayer,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,InitialLearnRate,ValidationFrequency,testdata)

Data_all=[Data];
mu_data = mean([Data; testdata]);
sig_data = std([Data; testdata]);

for i=1:size(Data_all,2)
    normalize_data_all(:,i) = (Data_all(:,i) - mu_data(i)) / sig_data(i);
end
for i=1:size(testdata,2)
    normalize_testdata(:,i) = (testdata(:,i) - mu_data(i)) / sig_data(i);
end
XreTrain = normalize_data_all(1:end,2:end)';
YreTrain = normalize_data_all(1:end,1)';
Results_test.YreCal_raw = Data_all(1:end,1);
Xtest = normalize_testdata(1:end,2:end)';
Ytest = normalize_testdata(1:end,1)';
Results_test.Ytest_raw = testdata(1:end,1);

% LSTM setting
Ini_Layer=0;
InputSize = size(Data_all,2)-1;
OutputSize = 1;

% LSTM modeling
for i=1:1
    [Results_test.Time_build(i), Results_test.LSTMmodel_test{i}, Results_test.Y_reCal(:,i), Results_test.info{i}]=LSTM_training_test(Ini_Layer,numlayer,InputSize,OutputSize,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
    XreTrain,YreTrain,mu_data,sig_data,InitialLearnRate,ValidationFrequency);
    
    Results_test.NS_Cal(i) = Nash(Results_test.YreCal_raw,Results_test.Y_reCal(:,i));
    Results_test.NRMSE_Cal(i) = NRMSE_compute(Results_test.YreCal_raw,Results_test.Y_reCal(:,i));
    CR_test=corrcoef(Results_test.YreCal_raw,Results_test.Y_reCal(:,i));
    Results_test.CR_Cal(i) = CR_test(1,2);
    Results_test.NMAE_Cal(i) = mae(Results_test.YreCal_raw,Results_test.Y_reCal(:,i))/(max(Results_test.YreCal_raw)-min(Results_test.YreCal_raw));
    
    % LSTM test
    tic;
    Results_test.Y_test(:,i) = LSTM_test(Results_test.LSTMmodel_test{i},Xtest,mu_data,sig_data);
    Results_test.Time_apply_test(i) = toc;
    Results_test.NS_test(i) = Nash(Results_test.Ytest_raw,Results_test.Y_test(:,i));
    Results_test.NRMSE_test(i) = NRMSE_compute(Results_test.Ytest_raw,Results_test.Y_test(:,i));
    CR_test=corrcoef(Results_test.Ytest_raw,Results_test.Y_test(:,i));
    Results_test.CR_test(i) = CR_test(1,2);
    Results_test.NMAE_test(i) = mae(Results_test.Ytest_raw,Results_test.Y_test(:,i))/(max(Results_test.Ytest_raw)-min(Results_test.Ytest_raw));
    
end
end

%test training
function [Timere, LSTMmodel_test, Y_reCal, infore]=LSTM_training_test(Ini_Layer,numlayer,InputSize,OutputSize,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
    XreTrain,YreTrain,mu_data,sig_data,InitialLearnRate,ValidationFrequency)
tic;

% Layer setting
if numlayer == 0
layers = Ini_Layer;
elseif numlayer == 1
layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
elseif numlayer == 2
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
    
elseif numlayer == 3
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
    
elseif numlayer == 4
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
        
elseif numlayer == 5
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];        

elseif numlayer == 6
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 7
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 8
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 9
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 10
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      
end
    

options2 = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',InitialLearnRate, ...
    'SequenceLength',miniBatchSize, ...
    'Verbose',0);

% Train LSTM Network
[LSTMmodelre infore]= trainNetwork(XreTrain,YreTrain,layers,options2);
Timere = toc;
% Application
% Calibration
LSTMmodel_test = LSTMmodelre;

for i=1:size(YreTrain,2)
    [LSTMmodel_test,Y_reCal(i,1)] = predictAndUpdateState(LSTMmodel_test,XreTrain(:,i));
end
Y_reCal = sig_data(1)*Y_reCal + mu_data(1);

end

%%
function Y_LSTM_test=LSTM_test(LSTMmodel_test,Xtest,mu_data,sig_data)

    for i=1:size(Xtest,2)
        [LSTMmodel_test,Y_LSTM_test(i,1)] = predictAndUpdateState(LSTMmodel_test,Xtest(:,i));
    end

Y_LSTM_test = sig_data(1)*Y_LSTM_test + mu_data(1);
end
%%
function NS = Nash(Qobs,Qtt)
%Nash-Sutcliffe coefficient calculation
A = 0.;
B = 0.;
C = 0.;
N = numel(Qtt);
for i = 1:N
    A = A+(Qtt(i)-Qobs(i))^2; 
    B = B+Qobs(i);
end
X = B/N;
AA = A;
for i = 1:N
    C = C+(Qobs(i)-X)^2;
end
CC = C;
Nash = 1-A/C;
NS = Nash;
end

%%
function NRMSE = NRMSE_compute(Obs, Sim)
N = numel(Sim);
NRMSE    = sqrt(sum((Obs(1:N)-Sim(1:N)).^2)/N)/max((Obs(1:N))-min(Obs(1:N)));

end