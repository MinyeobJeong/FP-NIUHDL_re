clear all
clc

header_hsd=load ('hsd_header.txt');
DEM_hsd=load ('hsd_topo.txt');
ncols_hsd=header_hsd(1,1);
nrows_hsd=header_hsd(2,1);
xllcorner_hsd=header_hsd(3,1);
yllcorner_hsd=header_hsd(4,1);
cellsize_hsd=header_hsd(5,1);
NODATA_value_hsd=header_hsd(6,1);
for i=1:nrows_hsd
    for j=1:ncols_hsd
        x_hsd(i,j)=xllcorner_hsd+(j-1)*cellsize_hsd;
        y_hsd(i,j)=yllcorner_hsd+nrows_hsd*cellsize_hsd-(i-1)*cellsize_hsd;
        if DEM_hsd(i,j)==NODATA_value_hsd
            x_hsd(i,j)=NaN;
            y_hsd(i,j)=NaN;
            DEM_hsd(i,j)=NaN;
        end
    end
end

false_easting=755850;
false_northing=1499500;
header_ydl=load ('ydl_header.txt');
DEM_ydl=load ('ydl_topo.txt');
ncols_ydl=header_ydl(1,1);
nrows_ydl=header_ydl(2,1);
xllcorner_ydl=header_ydl(3,1);
yllcorner_ydl=header_ydl(4,1);
cellsize_ydl=header_ydl(5,1);
NODATA_value_ydl=header_ydl(6,1);
for i=1:nrows_ydl
    for j=1:ncols_ydl
        x_ydl(i,j)=xllcorner_ydl+(j-1)*cellsize_ydl+false_easting;
        y_ydl(i,j)=yllcorner_ydl+nrows_ydl*cellsize_ydl-(i-1)*cellsize_ydl+false_northing;
        if DEM_ydl(i,j)==NODATA_value_ydl
            x_ydl(i,j)=NaN;
            y_ydl(i,j)=NaN;
            DEM_ydl(i,j)=NaN;
        end
    end
end

header_k=load ('korea_header.txt');
DEM_k=load ('korea_topo.txt');
ncols_k=header_k(1,1);
nrows_k=header_k(2,1);
xllcorner_k=header_k(3,1);
yllcorner_k=header_k(4,1);
cellsize_k=header_k(5,1);
NODATA_value_k=header_k(6,1);
for i=1:nrows_k
    for j=1:ncols_k
        x_k(i,j)=xllcorner_k+(j-1)*cellsize_k;
        y_k(i,j)=yllcorner_k+nrows_k*cellsize_k-(i-1)*cellsize_k;
        if DEM_k(i,j)==NODATA_value_k | DEM_k(i,j)==0
            x_k(i,j)=NaN;
            y_k(i,j)=NaN;
            DEM_k(i,j)=NaN;
        end
    end
end

hsd_location=[1047287.67059 1950030.57288];
ydl_location=[298516.61957231+false_easting 452048.743602570+false_northing];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gcf_topo=figure(1)
subplot (1,9,[1 2 3])
pcolor(x_k,y_k,DEM_k)
hold on
scatter(x_hsd(round(nrows_hsd/2),round(nrows_hsd/2)),...
              y_hsd(round(nrows_hsd/2),round(nrows_hsd/2)),200,...
              'MarkerEdgeColor','k',...
              'MarkerFaceColor','g',...
              'LineWidth',1.2)
shading interp
colormap('gray');
brighten(-.0)
xlim([min(x_k(:))-5000 1260000])
ylim([1573000 max(y_k(:))+1000])
xticks([]);
yticks([]);
title('[Location map]')
set(gca,'Fontname','times','Fontsize',20)
xlabel(sprintf('Korea\nPeninsula'))

subplot (1,9,[5 6 7 8 9])
pcolor((x_hsd-min(min(x_hsd)))/1000+0.1,(y_hsd-min(min(y_hsd)))/1000+0.1,DEM_hsd)
hold on
bound=[rmmissing(x_hsd(:)) rmmissing(y_hsd(:))];%load("hsd_boundary.txt");
idx=boundary(bound(:,1),bound(:,2),0.8);
plot((bound(idx,1)-min(min(x_hsd)))/1000+0.1, (bound(idx,2)-min(min(y_hsd)))/1000+0.1,...
    '-','color',[1 .23 .23],'linewidth',4)
hold on
p1=scatter((hsd_location(1)-min(min(x_hsd)))/1000+0.1,(hsd_location(2)-min(min(y_hsd)))/1000+0.1,300,'s',...
              'MarkerEdgeColor',[1 .23 .23],...
              'MarkerFaceColor',[1 .8 .8],...
              'LineWidth',2)
hold on
bound=[rmmissing(x_ydl(:)) rmmissing(y_ydl(:))];%load("ydl_boundary.txt");
idx=boundary(bound(:,1),bound(:,2),0.8);
% plot((bound(idx,1)+false_easting-min(min(x_hsd)))/1000+0.1, (bound(idx,2)+false_northing-min(min(y_hsd)))/1000+0.1,...
%     '-','color',[.23 .23 1],'linewidth',4)
plot((bound(idx,1)-min(min(x_hsd)))/1000+0.1, (bound(idx,2)-min(min(y_hsd)))/1000+0.1,...
    ':','color',[.3 .3 1],'linewidth',5)
hold on
p2=scatter((ydl_location(1)-min(min(x_hsd)))/1000+0.1,(ydl_location(2)-min(min(y_hsd)))/1000+0.1,300,'s',...
              'MarkerEdgeColor',[.3 .3 1],...
              'MarkerFaceColor',[.8 .8 1],...
              'LineWidth',2)
caxis([min(min(DEM_hsd)) max(max(DEM_hsd))]);
shading interp
colormap('gray');
brighten(-.0)
c=colorbar;
set(c,'position',[.542 .6 .016 .22])
title(c,'Elevation (m)');
set(gca,'Fontname','times','Fontsize',20)
xlabel('distance (km)')
ylabel('distance (km)')
xlim([0 (max(max(x_hsd))-min(min(x_hsd)))/1000+0.2])
ylim([0 (max(max(y_hsd))-min(min(y_hsd)))/1000+0.2])
title('[Topography]')
legend([p1 p2],'Hoengseong Dam','Yuldongli Gauge')
legend boxoff
set(gcf_topo,'units','normalized','outerposition',[0.01 0.25 0.7 0.7]);