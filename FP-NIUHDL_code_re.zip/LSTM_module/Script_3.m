clear all;clc;

Redata=load('File_2.txt');
M_numfactor = [2:1:14];
M_maxEpochs = [10:15:100];
M_InitialLearnRate = [0.001:0.001:0.01];
M_miniBatchSize = [10:30:250];
M_numlayer = [1:1:10];
M_numHiddenUnits = [50:50:350];
M_DropoutRate = [0:0.1:0.5];
M_ValidationFrequency = [1:11:100];

for i=1:13
    for j=1:width(M_numfactor)
       opt_result(i,j)=0;
    end
end

step=0;
criterion=0;
fold=4;

while step<inf
    step=step+1
    stepstep=rem(step,width(M_numfactor))
    
    if stepstep==0
        stepstep=width(M_numfactor);
    end
    
    numfactor = M_numfactor(stepstep);
    maxEpochs = randsample(M_maxEpochs,1);
    InitialLearnRate = randsample(M_InitialLearnRate,1);
    miniBatchSize = randsample(M_miniBatchSize,1);
    numlayer = randsample(M_numlayer,1);
    numHiddenUnits = randsample(M_numHiddenUnits,1);
    DropoutRate = randsample(M_DropoutRate,1);
    ValidationFrequency = randsample(M_ValidationFrequency,1);   
    
    testdata = [Redata(ceil(0.8*end)+1:end,end) Redata(ceil(0.8*end)+1:end,1:numfactor)];
    Data = [Redata(1:ceil(0.8*end),end) Redata(1:ceil(0.8*end),1:numfactor)];
    Data= sortrows(Data,1);
    Data_ori=Data;
    
    iteration=0;
    while iteration<fold
        Data=Data_ori;
        iteration=iteration+1;
        idx=round([iteration:(height(Data)-fold+1)/round(height(Data)/fold):...
            height(Data)-fold+iteration]);
        evaldata=Data(idx,:);
        Data(idx,:)=[];

        Results = LSTM_optimization(Data,...
            numlayer,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
            InitialLearnRate,ValidationFrequency,testdata,evaldata,iteration);

        NSE(iteration)=Results.NS_Eval;
        NRMSE(iteration)=Results.NRMSE_Eval;
        CR(iteration)=Results.CR_Eval;
        NMAE(iteration)=Results.NMAE_Eval;
        criterion(iteration)=(round(NSE(iteration),4)+...
            1-round(NRMSE(iteration),4)+...
            round(CR(iteration),4)+...
            1-round(NMAE(iteration),4))/4;
        if iteration==fold
            if round(mean(criterion(:)),2)> opt_result(13,stepstep) 
                opt_result(1,stepstep)=numfactor;
                opt_result(2,stepstep)=maxEpochs;
                opt_result(3,stepstep)=InitialLearnRate;
                opt_result(4,stepstep)=miniBatchSize;
                opt_result(5,stepstep)=numlayer;
                opt_result(6,stepstep)=numHiddenUnits;
                opt_result(7,stepstep)=DropoutRate;
                opt_result(8,stepstep)=ValidationFrequency;
                opt_result(9,stepstep)=round(mean(NSE(:)),2);
                opt_result(10,stepstep)=round(mean(NRMSE(:)),2);
                opt_result(11,stepstep)=round(mean(CR(:)),2);
                opt_result(12,stepstep)=round(mean(NMAE(:)),2);
                opt_result(13,stepstep)=round(mean(criterion(:)),2);
                dlmwrite('File_3.txt',opt_result);
            end
        end
    end
end

%% Function
function Results = LSTM_optimization(Data,numlayer,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,InitialLearnRate,ValidationFrequency,testdata,evaldata,iteration)

mu_data = mean([Data; evaldata]);
sig_data = std([Data; evaldata]);

for i=1:size(Data,2)
    normalize_data(:,i) = (Data(:,i) - mu_data(i)) / sig_data(i);
end
for i=1:size(evaldata,2)
    normalize_evaldata(:,i) = (evaldata(:,i) - mu_data(i)) / sig_data(i);
end
XTrain = normalize_data(1:end,2:end)';
YTrain = normalize_data(1:end,1)';
Results.YCal_raw = Data(1:end,1);
XEval = normalize_evaldata(1:end,2:end)';
YEval = normalize_evaldata(1:end,1)';
Results.YEval_raw = evaldata(1:end,1);
Ini_Layer=0;
InputSize = size(Data,2)-1;
OutputSize = 1;


% LSTM modeling
for i=1:1
    [Results.Time_build(i), Results.LSTMmodel{i}, Results.Y_Cal(:,i), Results.info{i}]=LSTM_training(Ini_Layer,numlayer,InputSize,OutputSize,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
        XTrain,YTrain,XEval,YEval,mu_data,sig_data,InitialLearnRate,ValidationFrequency);
    
    Results.NS_Cal(i) = Nash(Results.YCal_raw,Results.Y_Cal(:,i));
    Results.NRMSE_Cal(i) = NRMSE_compute(Results.YCal_raw,Results.Y_Cal(:,i));
    CR=corrcoef(Results.YCal_raw,Results.Y_Cal(:,i));
    Results.CR_Cal(i) = CR(1,2);
    Results.NMAE_Cal(i) = mae(Results.YCal_raw,Results.Y_Cal(:,i))/(max(Results.YCal_raw)-min(Results.YCal_raw));
    
    % LSTM evaluation
    tic;
    Results.Y_Eval(:,i) = LSTM_eval(Results.LSTMmodel{i},XEval,mu_data,sig_data);
    Results.Time_apply(i) = toc;

    Results.NS_Eval= Nash(Results.YEval_raw,Results.Y_Eval(:,i));
    Results.NRMSE_Eval= NRMSE_compute(Results.YEval_raw,Results.Y_Eval(:,i));
    CR=corrcoef(Results.YEval_raw,Results.Y_Eval(:,i));
    Results.CR_Eval= CR(1,2);
    Results.NMAE_Eval= mae(Results.YEval_raw,Results.Y_Eval(:,i))/(max(Results.YEval_raw)-min(Results.YEval_raw));
end
end


%validation training
function [Time, LSTMmodel, Y_Cal, info]=LSTM_training(Ini_Layer,numlayer,InputSize,OutputSize,numHiddenUnits,DropoutRate,miniBatchSize,maxEpochs,...
    XTrain,YTrain,XEval,YEval,mu_data,sig_data,InitialLearnRate,ValidationFrequency)
tic;

% Layer setting
if numlayer == 0
layers = Ini_Layer;
elseif numlayer == 1
layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
elseif numlayer == 2
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
    
elseif numlayer == 3
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
    
elseif numlayer == 4
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];
        
elseif numlayer == 5
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];        

elseif numlayer == 6
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 7
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 8
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 9
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      

elseif numlayer == 10
    layers = [ ...
    sequenceInputLayer(InputSize)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    lstmLayer(numHiddenUnits)
    dropoutLayer(DropoutRate)
    fullyConnectedLayer(OutputSize)
    regressionLayer];      
end
    

options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',InitialLearnRate, ...
    'ValidationData',{XEval,YEval}, ...
    'ValidationFrequency',ValidationFrequency, ...
    'SequenceLength',miniBatchSize, ...
    'Verbose',0);


[LSTMmodel info]= trainNetwork(XTrain,YTrain,layers,options);
Time = toc;
LSTMmodel_cal = LSTMmodel;

for i=1:size(YTrain,2)
    [LSTMmodel_cal,Y_Cal(i,1)] = predictAndUpdateState(LSTMmodel_cal,XTrain(:,i));
end
Y_Cal = sig_data(1)*Y_Cal + mu_data(1);

end


%%
function Y_LSTM=LSTM_eval(LSTMmodel,XEval,mu_data,sig_data)

    for i=1:size(XEval,2)
        [LSTMmodel,Y_LSTM(i,1)] = predictAndUpdateState(LSTMmodel,XEval(:,i));
    end

Y_LSTM = sig_data(1)*Y_LSTM + mu_data(1);
end
%%
function NS = Nash(Qobs,Qtt)
%Nash-Sutcliffe coefficient calculation
A = 0.;
B = 0.;
C = 0.;
N = numel(Qtt);
for i = 1:N
    A = A+(Qtt(i)-Qobs(i))^2; 
    B = B+Qobs(i);
end
X = B/N;
AA = A;
for i = 1:N
    C = C+(Qobs(i)-X)^2;
end
CC = C;
Nash = 1-A/C;
NS = Nash;
end

%%
function NRMSE = NRMSE_compute(Obs, Sim)
N = numel(Sim);
NRMSE    = sqrt(sum((Obs(1:N)-Sim(1:N)).^2)/N)/max((Obs(1:N))-min(Obs(1:N)));

end